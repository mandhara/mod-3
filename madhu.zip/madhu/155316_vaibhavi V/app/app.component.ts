import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'mobile-component',
    templateUrl: 'mobile-component.component.html',
    styleUrls: ['mobile-component.component.scss']
})
export class MobileComponentComponent {
    title = 'myApp';
    name='hello';
    mycolor='green';
    
}


 