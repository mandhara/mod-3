package com.capgemin.ams.client;

import java.util.Scanner;

import com.capgemin.ams.dao.DaoImpl;
import com.capgemin.ams.entities.Trainee;

public class Client {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		Scanner scanner1 = new Scanner(System.in);
		System.out.println("Enter Trainee name:");
		String name=scanner.nextLine();
		System.out.println("Enter Module name:");
		String mname=scanner.nextLine();
		System.out.println("Enter MPT Score:");
		int mpt=scanner1.nextInt();
		System.out.println("Enter MTT Score:");
		int mtt=scanner1.nextInt();
		System.out.println("Enter Assaignment Marks:");
		int assign=scanner1.nextInt();
		
		int total=mpt+mtt+assign;
		Trainee trainee= new Trainee();
		int id=trainee.getDetailsId();
		trainee= new Trainee(id,name,mname,mpt,mtt,assign,total);
		
		DaoImpl dao = new DaoImpl();
		dao.beginTransaction();
		
		dao.addDetails(trainee);
		dao.commitTransaction();
		
		
	}

}
