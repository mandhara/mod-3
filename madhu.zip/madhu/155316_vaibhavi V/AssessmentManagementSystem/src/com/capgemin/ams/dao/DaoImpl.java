package com.capgemin.ams.dao;

import javax.persistence.EntityManager;

import com.capgemin.ams.entities.Trainee;


public class DaoImpl {
	
	EntityManager entityManager = JPAUtil.getEntityManager();
	
	public int addDetails(Trainee trainee){
		
		
		entityManager.persist(trainee);
		
		
		return 0;
		
	}
	
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

}
