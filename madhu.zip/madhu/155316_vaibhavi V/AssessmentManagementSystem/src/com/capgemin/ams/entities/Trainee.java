package com.capgemin.ams.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="Trainee_Details")
public class Trainee implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int detailsId;
	private String traineeName;
	private String moduleName;
	private int mptMarks;
	private int mttMarks;
	private int assaignmentMarks;
	private int total;
	public int getDetailsId() {
		return detailsId;
	}
	public void setDetailsId(int detailsId) {
		this.detailsId = detailsId;
	}
	
	
	public Trainee() {
		super();
	}
	
	
	
	public Trainee(int detailsId, String traineeName, String moduleName,
			int mptMarks, int mttMarks, int assaignmentMarks, int total) {
		super();
		this.detailsId = detailsId;
		this.traineeName = traineeName;
		this.moduleName = moduleName;
		this.mptMarks = mptMarks;
		this.mttMarks = mttMarks;
		this.assaignmentMarks = assaignmentMarks;
		this.total = total;
	}
	
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public int getMptMarks() {
		return mptMarks;
	}
	public void setMptMarks(int mptMarks) {
		this.mptMarks = mptMarks;
	}
	public int getMttMarks() {
		return mttMarks;
	}
	public void setMttMarks(int mttMarks) {
		this.mttMarks = mttMarks;
	}
	public int getAssaignmentMarks() {
		return assaignmentMarks;
	}
	public void setAssaignmentMarks(int assaignmentMarks) {
		this.assaignmentMarks = assaignmentMarks;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	
	
	
	
	

}
