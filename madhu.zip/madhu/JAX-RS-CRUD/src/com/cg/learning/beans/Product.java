package com.cg.learning.beans;

/**
 * 
 *
 * Product bean with getters and setters and default and parametarized constructor
 */
public class Product {
	private int pId;
	private String pName;
	private float price;

	public Product() {

	}

	public Product(int pId, String pName, float price) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.price = price;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	
}
