package com.cg.learning.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.learning.beans.Product;
import com.cg.learning.staticdb.productDB;

public class ProductDAOImpl implements IProductDAO {
	static HashMap<Integer, Product> productIdMap = productDB.getProductIdMap();

	public List<Product> getAllProducts() {
		List<Product> countries = new ArrayList<Product>(productIdMap.values());
		return countries;
	}

	public Product getProduct(int id) {
		Product product = productIdMap.get(id);
		return product;
	}

	public Product addProduct(Product product) {
		productIdMap.put(product.getpId(), product);
		return product;
	}

	public Product updateProduct(Product product) {
		if (product.getpId() <= 0)
			return null;
		productIdMap.put(product.getpId(), product);
		return product;

	}

}
