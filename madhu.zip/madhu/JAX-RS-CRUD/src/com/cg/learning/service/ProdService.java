package com.cg.learning.service;

import java.util.List;


import com.cg.learning.beans.Product;
import com.cg.learning.dao.ProductDAOImpl;
import com.cg.learning.dao.IProductDAO;

public class ProdService implements IProdService {
	IProductDAO dao;

	public ProdService() {
		dao = new ProductDAOImpl();
	}

	
	public List<Product> getAllProducts() {
		return dao.getAllProducts();
	}


	public Product getProduct(int id) {
		return dao.getProduct(id);
	}

	public Product addProduct(Product product) {
		return dao.addProduct(product);
	}

	

}
