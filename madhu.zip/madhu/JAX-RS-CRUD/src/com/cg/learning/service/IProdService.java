package com.cg.learning.service;

import java.util.List;


import com.cg.learning.beans.Product;

public interface IProdService {
	public List<Product> getAllProducts();
	public Product getProduct(int id);
	public Product addProduct(Product product);
	
}
